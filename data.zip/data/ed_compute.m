clc;clear;
data1=xlsread('C:\Users\Administrator\Desktop\dataa\road_ref.xlsx');
data2=xlsread('C:\Users\Administrator\Desktop\dataa\Left lane with roadside constraint\Driver A.xlsx');
%Lane centerline of reference trajectory
xr=data1(:,2);
yr=data1(:,3);
phir=data1(:,4);
%Find the nearest sample point to the vehicle's current position  
x_pre=data2(:,8);
y_pre=data2(:,9);
n=length(xr);m=length(x_pre);
for i=1:m
    d_m=(x_pre(i)-xr(1))^2+(y_pre(i)-yr(1))^2;
    w=1;
    x=x_pre(i);y=y_pre(i);
    for j=1:n
        d=(x-xr(j))^2+(y-yr(j))^2;
        if d<d_m
            d_m=d;
            w=j;
        end
    end
  %calculate error
    p=w;
   % tor=[cos(theta_r(p));sin(theta_r(p))];
    Y=[-sin(phir(p));cos(phir(p))];
    deltaP=[x-xr(p);y-yr(p)];
    e1(i)=Y'*deltaP;
end
 ed=e1'; 
t=data2(:,1);plot(t,ed,'-k');
xlim([0,80]);
